/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projRandom;
import java.util.Random;
/**
 *
 * @author User
 */
public class principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Random randomList = new Random ();
        int d = 50000;
       
        for (int i=0; i < d;i++ )  {
           int aleatorio = randomList.nextInt(d);
            System.out.println("*** :" +aleatorio);
        }
        
            
            }
}
